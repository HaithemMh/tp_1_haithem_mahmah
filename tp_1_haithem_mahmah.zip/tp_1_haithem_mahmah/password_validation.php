<?php
// Inclusion du fichier contenant les fonctions nécessaires pour la validation et le chiffrement des mots de passe
include 'password_functions.php';

// Vérifie si la méthode de requête est POST (c'est-à-dire si le formulaire a été soumis) 
// et si la valeur du mot de passe a été définie dans le POST
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['password'])) {
    
    // Appelle la fonction validateAndEncryptPassword pour valider et chiffrer le mot de passe
    $result = validateAndEncryptPassword($_POST['password']);
    
    // Vérifie si la validation a réussi
    if ($result['success']) {
        // Affiche le message de succès et les détails du mot de passe chiffré
        echo "Mot de passe validé avec succès.<br>";
        echo "Sel utilisé : " . $result['salt'] . "<br>";
        echo "Mot de passe chiffré : " . $result['encryptedPassword'];
    } else {
        // Si la validation échoue, affiche le message d'erreur renvoyé par la fonction
        echo $result['message'];
    }
}
?>

<!-- Formulaire HTML permettant à l'utilisateur de saisir un mot de passe -->
<form method="post" action="">
    Entrez le mot de passe : <input type="password" name="password">
    <input type="submit" value="Valider">
</form>
