<?php

function validateAndEncryptPassword($password) {
    // Définir le sel
    $salt = "ABC1234@";

    // Vérification de la longueur du mot de passe
    if (strlen($password) < 6 || strlen($password) > 10) {
        return array(
            'success' => false,
            'message' => "Erreur : Le mot de passe doit comporter entre 6 et 10 caractères."
        );
    }

    // Concaténation du mot de passe avec le sel
    $passwordWithSalt = $password . $salt;

    // Chiffrement du mot de passe avec le sel
    $encryptedPassword = password_hash($passwordWithSalt, PASSWORD_BCRYPT);

    return array(
        'success' => true,
        'salt' => $salt,
        'encryptedPassword' => $encryptedPassword
    );
}

function checkPassword($inputPassword, $hashedPassword) {
    $salt = "ABC1234@";
    return password_verify($inputPassword . $salt, $hashedPassword);
}

?>
